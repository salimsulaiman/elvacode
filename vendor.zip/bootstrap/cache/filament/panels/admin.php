<?php return array (
  'livewireComponents' => 
  array (
    'app.filament.resources.article-categories.pages.create-article-category' => 'App\\Filament\\Resources\\ArticleCategories\\Pages\\CreateArticleCategory',
    'app.filament.resources.article-categories.pages.edit-article-category' => 'App\\Filament\\Resources\\ArticleCategories\\Pages\\EditArticleCategory',
    'app.filament.resources.article-categories.pages.list-article-categories' => 'App\\Filament\\Resources\\ArticleCategories\\Pages\\ListArticleCategories',
    'app.filament.resources.articles.pages.create-article' => 'App\\Filament\\Resources\\Articles\\Pages\\CreateArticle',
    'app.filament.resources.articles.pages.edit-article' => 'App\\Filament\\Resources\\Articles\\Pages\\EditArticle',
    'app.filament.resources.articles.pages.list-articles' => 'App\\Filament\\Resources\\Articles\\Pages\\ListArticles',
    'app.filament.resources.portfolio-categories.pages.create-portfolio-category' => 'App\\Filament\\Resources\\PortfolioCategories\\Pages\\CreatePortfolioCategory',
    'app.filament.resources.portfolio-categories.pages.edit-portfolio-category' => 'App\\Filament\\Resources\\PortfolioCategories\\Pages\\EditPortfolioCategory',
    'app.filament.resources.portfolio-categories.pages.list-portfolio-categories' => 'App\\Filament\\Resources\\PortfolioCategories\\Pages\\ListPortfolioCategories',
    'app.filament.resources.portfolios.pages.create-portfolio' => 'App\\Filament\\Resources\\Portfolios\\Pages\\CreatePortfolio',
    'app.filament.resources.portfolios.pages.edit-portfolio' => 'App\\Filament\\Resources\\Portfolios\\Pages\\EditPortfolio',
    'app.filament.resources.portfolios.pages.list-portfolios' => 'App\\Filament\\Resources\\Portfolios\\Pages\\ListPortfolios',
    'filament.pages.dashboard' => 'Filament\\Pages\\Dashboard',
    'filament.widgets.account-widget' => 'Filament\\Widgets\\AccountWidget',
    'filament.widgets.filament-info-widget' => 'Filament\\Widgets\\FilamentInfoWidget',
    'filament.livewire.database-notifications' => 'Filament\\Livewire\\DatabaseNotifications',
    'filament.auth.pages.edit-profile' => 'Filament\\Auth\\Pages\\EditProfile',
    'filament.livewire.global-search' => 'Filament\\Livewire\\GlobalSearch',
    'filament.livewire.notifications' => 'Filament\\Livewire\\Notifications',
    'filament.livewire.sidebar' => 'Filament\\Livewire\\Sidebar',
    'filament.livewire.simple-user-menu' => 'Filament\\Livewire\\SimpleUserMenu',
    'filament.livewire.topbar' => 'Filament\\Livewire\\Topbar',
    'filament.auth.pages.login' => 'Filament\\Auth\\Pages\\Login',
  ),
  'clusters' => 
  array (
  ),
  'clusteredComponents' => 
  array (
  ),
  'clusterDirectories' => 
  array (
  ),
  'clusterNamespaces' => 
  array (
  ),
  'pages' => 
  array (
    0 => 'Filament\\Pages\\Dashboard',
  ),
  'pageDirectories' => 
  array (
    0 => 'C:\\laragon\\www\\elvacode\\app\\Filament/Pages',
  ),
  'pageNamespaces' => 
  array (
    0 => 'App\\Filament\\Pages',
  ),
  'resources' => 
  array (
    'C:\\laragon\\www\\elvacode\\app\\Filament\\Resources\\ArticleCategories\\ArticleCategoryResource.php' => 'App\\Filament\\Resources\\ArticleCategories\\ArticleCategoryResource',
    'C:\\laragon\\www\\elvacode\\app\\Filament\\Resources\\Articles\\ArticleResource.php' => 'App\\Filament\\Resources\\Articles\\ArticleResource',
    'C:\\laragon\\www\\elvacode\\app\\Filament\\Resources\\PortfolioCategories\\PortfolioCategoryResource.php' => 'App\\Filament\\Resources\\PortfolioCategories\\PortfolioCategoryResource',
    'C:\\laragon\\www\\elvacode\\app\\Filament\\Resources\\Portfolios\\PortfolioResource.php' => 'App\\Filament\\Resources\\Portfolios\\PortfolioResource',
  ),
  'resourceDirectories' => 
  array (
    0 => 'C:\\laragon\\www\\elvacode\\app\\Filament/Resources',
  ),
  'resourceNamespaces' => 
  array (
    0 => 'App\\Filament\\Resources',
  ),
  'widgets' => 
  array (
    0 => 'Filament\\Widgets\\AccountWidget',
    1 => 'Filament\\Widgets\\FilamentInfoWidget',
  ),
  'widgetDirectories' => 
  array (
    0 => 'C:\\laragon\\www\\elvacode\\app\\Filament/Widgets',
  ),
  'widgetNamespaces' => 
  array (
    0 => 'App\\Filament\\Widgets',
  ),
);