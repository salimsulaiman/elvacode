<h2>Pesan dari {{ $data['name'] }}</h2>
<p><strong>Email:</strong> {{ $data['email'] }}</p>
<p><strong>Telepon:</strong> {{ $data['phone'] }}</p>
<p><strong>Alamat:</strong> {{ $data['address'] }}</p>
<p><strong>Subjek:</strong> {{ $data['subject'] }}</p>
<p><strong>Pesan:</strong><br>{{ $data['message'] }}</p>
