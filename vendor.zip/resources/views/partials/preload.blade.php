<div x-show="loaded" x-init="setTimeout(() => loaded = false, 400)"
    class="fixed inset-0 z-[999999] flex items-center justify-center bg-white/80 dark:bg-slate-900/80 backdrop-blur-sm"
    x-cloak>
    <div
        class="h-16 w-16 animate-spin rounded-full border-4 border-solid border-brand-500 border-t-transparent dark:border-white dark:border-t-transparent">
    </div>
</div>
