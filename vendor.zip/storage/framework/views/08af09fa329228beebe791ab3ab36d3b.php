<h2>Pesan dari <?php echo e($data['name']); ?></h2>
<p><strong>Email:</strong> <?php echo e($data['email']); ?></p>
<p><strong>Telepon:</strong> <?php echo e($data['phone']); ?></p>
<p><strong>Alamat:</strong> <?php echo e($data['address']); ?></p>
<p><strong>Subjek:</strong> <?php echo e($data['subject']); ?></p>
<p><strong>Pesan:</strong><br><?php echo e($data['message']); ?></p>
<?php /**PATH C:\laragon\www\elvacode\resources\views\emails\contact.blade.php ENDPATH**/ ?>