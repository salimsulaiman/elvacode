<p
    <?php echo e($attributes->class(['fi-section-header-description'])); ?>

>
    <?php echo e($slot); ?>

</p>
<?php /**PATH C:\laragon\www\elvacode\vendor\filament\support\resources\views\components\section\description.blade.php ENDPATH**/ ?>