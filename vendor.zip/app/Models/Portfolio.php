<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class Portfolio extends Model
{
    protected $fillable = ['name', 'slug', 'thumbnail', 'summary', 'content', 'category_id'];

    protected static function booted()
    {
        static::creating(function ($portfolio) {
            $baseSlug = Str::slug($portfolio->name);
            $slug = $baseSlug;
            $count = 1;

            while (self::where('slug', $slug)->exists()) {
                $slug = $baseSlug . '-' . $count;
                $count++;
            }

            $portfolio->slug = $slug;
        });
    }

    public function category()
    {
        return $this->belongsTo(PortfolioCategory::class, 'category_id');
    }
}
